#include<stdio.h>
 int main()
{
    int a,b, choice;
    printf("Enter the value of first number=");
    scanf("%d",&a);
    printf("Enter the value of second number=");
    scanf("%d",&b);
    printf("1.Addition\n");
    printf("2.subtraction\n");
    printf("3.multiplication\n");
    printf("4.Divition\n");
    printf("Enter the choice=");
    scanf("%d",&choice);
    switch (choice)
    {
        case 1:
        {
            int c=a+b;
            printf("Result=%d\n",c);
            break;
        }
        case 2:
        {
            int d=a-b;
            printf("Result=%d\n",d);
            break;
        }
        case 3:
        {
            int e=a*b;
            printf("Result=%d\n",e);
            break;
        }
        case 4:
        {
            int f=a/b;
            printf("Result=%d\n",f);
            break;
            default:
            printf("Invalide");
            
        }
        
    }
    return 0;
}