#include <stdio.h>

int main()
{
char ch;
printf("enter the character ");
scanf("%c",&ch);
switch(ch)
{
    case 'a' :
    case 'e' :
    case 'i' :
    case 'o' :
    case 'u' :
    case 'A' :
    case 'E' :
    case 'I' :
    case 'O' :
    case 'U' :
    
    printf("it is a vowel");
    break;
    
     printf("%c",ch);
     break;
     default:
     printf("consonent");
}
}