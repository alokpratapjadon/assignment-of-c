#include <stdio.h>
#include<conio.h>
int main()
{
    int radius;
    float area, perimeter;
    printf("Enter radius of circle");
    scanf("%d",&radius);
    areape(radius,&area,&perimeter);
    printf("Area=%0.1f",area);
    printf("perimeter=%0.1f",perimeter);
}
    areape(int r, float *area,float *perimeter)
{
    *area=3.14*r*r;
    *perimeter=2*3.14*r;
    getch();
}    
    
    