#include<stdio.h>
int main()
{
    int a,b;
    printf("Enter any first number\n");
    scanf("%d",&a);
    printf("Enter any second number\n");
    scanf("%d",&b);
    a=a^b;
    b=a^b;
    a=a^b;
    printf("result=%d\n",a);
    printf("result=%d\n",b);
    
}