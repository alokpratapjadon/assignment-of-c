#include <stdio.h>
int main()
{
    int a[5],number,i,j,temp;
    printf("\n Enter total no. of element");
    scanf("%d",&number);
    
    printf("\n Enter arry element");
    
    for (i=0; i<number; i++)
    {
        scanf("%d",&a[i]);
    }
    for (i=0; i<number-1; i++)
    {
        for (j=0; j<number-i-1; j++)
    {
        if (a[j]>a[j+1])
    {
        temp=a[j];
        a[j]=a[j+1];
        a[j+1]=temp;
    }
    }
    }
   
    printf("Array in asending order");
    
    for(i=0; 1<number; i++)
    {
        printf("%d\t",a[i]);
    }
    return 0;
}
