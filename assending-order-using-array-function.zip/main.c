#include <stdio.h>
int main()
{
    int a[100],number,i,j,temp;
    printf("\n Enter total no. of element");
    scanf("%d",&number);
    
    printf("\n Enter arry element");
    
    for (i=0; i<number; i++)
    {
        scanf("%d",&a[i]);
    }
    for (i=0; i<number-1; i++);
    {
        for (i=0; j<number-1-1; j++)
    {
        if (a[j]>a[j+1])
    {
        temp=a[j];
        a[j]=a[j+1];
        a[j+1]=temp;
    }
    }
    }
      //for disending order we have to use (number-1; i>=0; i--)
        
    printf("Array in asending order");
    
    for(i=0; 1<number; i++)
    {
        printf("%d\t",a[i]);
    }
    return 0;
}