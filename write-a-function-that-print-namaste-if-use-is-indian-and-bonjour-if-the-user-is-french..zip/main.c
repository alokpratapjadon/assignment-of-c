//Write a function that print Namaste if use is indian and bonjour if the user is French.
void printNameste();
void Bonjour();

int main(){
    printf("enter f for french and i for india:");
    char ch;
    scanf("%c",&ch);
    if(ch == 'i'){
        nameste();
    }
    else {
        bonjour();
        
    }
    return 0;
}
void nameste(){
    printf("nameste\n");
}
void bonjour(){
    printf("bonjour\n");
    
}