#include <stdio.h>
void printHello();

int main(){
printHello();
printHello();
printHello();
return 0;
}
void printHello(){
printf("my name is alok\n");
}
