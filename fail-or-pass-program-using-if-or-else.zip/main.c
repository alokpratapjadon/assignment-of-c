#include<stdio.h>
int main()

{
    int a;
    
    printf("Enter the marks");
    scanf("%d",&a);
    
    if (a>=30 && a<=100)
    printf("pass");
    
    else if (a<30)
    printf("fail");
    
    else
    printf("Extra odinary");
    return 0;
    
}
