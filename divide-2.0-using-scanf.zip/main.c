/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>

void main()
{
    int a,b,divide=0,sum=0,multiply=0;

    
    printf("Enter the value of a and b");
    scanf("%d%d",&a,&b);
    divide=a/b;
    printf("The divide is %d",divide); 

    
    printf("Enter the value of a and b");
    scanf("%d%d",&a,&b);
    sum=a+b;
    printf("The sum is %d",sum);
    


    
    printf("Enter the value of a and b");
    scanf("%d%d",&a,&b);
    multiply=a*b;
    printf("The multiply is %d",multiply);
    
}
