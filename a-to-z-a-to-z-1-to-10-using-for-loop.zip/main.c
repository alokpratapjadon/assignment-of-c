#include<stdio.h>
int main()

{   char i;
 
 for(i='a' ;i<='z' ; i++)
 
 {printf("%c "  ,i);}
 
 printf("\n");

 
  for(i='A' ;i<='Z' ; i++)
 
 {printf("%c "  ,i);}
 
  printf("\n");
 
 for(i=1 ;i<=10 ; i++)
 
 {printf("%d "  ,i);}
 
    return 0;
}
