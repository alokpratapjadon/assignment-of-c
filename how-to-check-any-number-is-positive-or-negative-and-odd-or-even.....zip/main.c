//how to check any number is positive or negative and odd or even....

#include <stdio.h>

 int main()
{
    int num;
    
    printf("Enter the value: \t");
    scanf("%d",&num);
    
    if (num % 2 == 0 && num>0)
    { printf("even and positive"); }
    
  else if (num % 2 == 0 && num<0)
    { printf("even and negative");}
        
    else if (num % 2 != 0 && num>0)
    { printf("odd and positive");}

else if (num % 2 != 0 && num<0)
    { printf("odd and negative");}
    
    return 0;
}
