
#include<stdio.h>
int main(){
    int age;
    printf("enter the age:");
    scanf("%d",&age);
    if(age>=59){
        printf("old");
    }
    else if(age<59 && age>18 ){
        printf("young");
    }
    else {
        printf("teen,child");
    }
    return 0;
}
