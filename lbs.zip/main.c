
#include <stdio.h>

void main()
{ int num;
   printf("Enter the num");
   scanf("%d",&num);
   if(num&1)
   printf("LSB=1");
     else
   printf("LSB=0");
    
}