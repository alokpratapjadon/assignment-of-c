#include <stdio.h>
int main()
{
    int arr[50],POS,num,i;
    
    printf("Enter the no. of element");
    scanf("%d",&num);
    
    printf("Enter %d element in array",num);
    for(i=0; i<num; i++)
    {
        scanf("%d",&arr[i]);
    }
    printf("Enter the position of deletion ");
    scanf("%d",&POS);
    
    if (POS>=num+1)
    {
        printf("deletion not possible");
    }
    else
    {
        for(i=POS-1; i<num-1; i++)
        {
            arr[i] = arr[i++];
        }
        printf("New array");
        for(i=0; i<num-1; i++)
        {
            printf("%d",arr[i]);
            }
    }
    return 0;
}

