
#include <stdio.h>

int main()
{
  int s[4][2]={
      {123,56},
      {1212,35},
      {1434,80},
      {1312,783},
  };
  int i;
  for(i=0;i<=3;i++)
  printf("\n Address=%u",s[i]);
  
  
}
