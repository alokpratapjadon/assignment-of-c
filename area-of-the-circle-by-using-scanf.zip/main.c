
#include <stdio.h>
#define PI 3.14
void main()
{
    int r;
    float area;
    printf("Enter radius\n");
    scanf("%d",&r);

    area = PI*r*r;
    printf("area = %f\n",area);
    return 0;
}

