
#include <stdio.h>

int main()
{
   int a,b,c;
    printf("Entet the value  of a\n");
    scanf("%d",&a);
    printf("Enter the value of b\n");
    scanf("%d",&b);
    c=a+b;
    printf("Sum=%d",c);
    return 0;
}

