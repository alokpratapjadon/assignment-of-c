//True->1
//False->0

#include<stdio.h>
int main()
{
    int x;
    printf("Enter the number:");
    scanf("%d",&x);
    printf("%d\n",x>1000 && x<5000);
    
    
    return 0;
}