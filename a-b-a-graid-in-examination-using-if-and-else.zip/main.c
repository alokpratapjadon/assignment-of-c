#include<stdio.h>
int main()
{
    int marks;
    
    printf("Enter the numbers of the student in the Examination :\t");
    scanf("%d",&marks);
    
    if (marks>=70 && marks<90)
  {  printf("A");}
    
   else if (marks<70 && marks>=30)
    {printf("B");}
    
   else if (marks>=90 && marks<=100)
    {printf("A+");}
    
    else printf("Fail");
    

     return 0;
}