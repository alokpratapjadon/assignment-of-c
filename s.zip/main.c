#include<stdio.h>
int main()

{   int i;

  printf("Counting from 0 to 10 =\t");
    for(i =0; i <=10 ; i=i+1)
    {
      
        printf("%d\t ", i);
    }
    return 0;
}