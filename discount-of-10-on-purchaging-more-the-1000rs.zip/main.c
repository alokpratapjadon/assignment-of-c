#include <stdio.h>

void main()
{
    int qty,dis=0;
    float pr,tot;
    
    printf("enter the quanit and price/rate");
    scanf("%d%f",&qty,&pr);
    
if(qty>1000)
{dis=10;
}

tot=pr*qty-(pr*qty*dis)/100;
printf("%f",tot);
    
    
}

