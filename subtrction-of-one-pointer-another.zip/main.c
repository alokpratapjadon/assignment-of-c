#include <stdio.h>
int main()
{
    int arr[]={10,20,30,45,67,57,74};
int *i,*j;
i=&arr[1];
j=&arr[5];
printf("%d%d",j-i,*j-*i);
    
    
}
