#include<stdio.h>
int main()
{
    char day;
    printf("Enter a latter (a to g)\t:\t");
    scanf("%c", &day);
    
    switch(day)
    {
        case 'a' :printf("Monday \n");
        break;
        
        case 'b':printf("Tuesday \n");
        break;
        
        case 'c':printf("Wednesday \n");
        break;
        
        case 'd':printf("Thursday \n");
        break;
        
        case 'e':printf("Friday \n");
        break;
        
        case 'f':printf("Saturday \n");
        break;
    
        case 'g':printf("Sunday \n");
        break;
    
        default: printf("Not a valid day");
    }
        return 0;
       
}
