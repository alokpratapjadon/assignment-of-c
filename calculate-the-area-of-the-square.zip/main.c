#include <stdio.h>
//area of square
 int main()
 {
     int side;
     printf("Enter side");
     scanf("%d",&side);
    printf("are %d", side*side);
    return 0;
     
     
 }