#include<stdio.h>
int main()

{   int i;
    for(i = 98; i <= 980 ; i = i+98)
    {
        printf("%d \n", i);
    }
    return 0;
}